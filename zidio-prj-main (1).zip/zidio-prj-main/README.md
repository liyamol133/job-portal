zidio project
